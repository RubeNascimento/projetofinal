<template>
    <div class="background">
            <div class="informacoes">
                <div class="row"
                outlined
                v-for="(item, index) in info"
                :key="index"
                >
                    <h1 class="title">{{ item.titulo }}</h1>
                        <p class="text"></p>
                            
                                <p class="texto-botao">
                                Banda: {{ item.banda }}
                                </p>
                                <p class="texto-botao">
                                Nº faixas: {{ item.n_faixas }}
                                </p>
                                <p class="texto-botao">
                                Ano: {{ item.ano }}
                                </p>
                </div>
            </div>
            <div class="imagens">
                <div class="imagem1"></div>
                <div class="imagem2"></div>
                <div class="imagem3"></div>
                <div class="imagem4"></div>
                <div class="imagem5"></div>
                <div class="imagem6"></div>
            </div>
    </div>
</template>

<script>
    import axios from "axios";
    export default {
        data() {
            return {
            info: null,
            };
        },
        mounted() {
            axios
            .get(
                "https://projeto-final-a13cc-default-rtdb.europe-west1.firebasedatabase.app/.json"
            )
            .then((response) => (this.info = response.data.data));
        },
    };
</script>

<style scoped>
.background {
    padding-top: 200px;
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: row;
    justify-content: center;
}
.informacoes {
    display: grid;
    grid-template-columns: 400px;
    grid-template-rows: repeat(6, 200px);
    grid-gap: 50px;
    justify-content: center;
}
.textoeimagens {
    display: flex;
    flex-direction: row;
    justify-content: center;
}
.row {
    border: 1px solid black;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background-color: white;
}
.imagens{
    display: flex;
    flex-direction: column;
    align-items: center;
    height: 1500px;
}
.imagem1 {
    background-image: url("../assets/a1.png");
    width: 200px;
    height: 200px;
    background-size: cover;
    border-top: 1px solid black;
    border-bottom: 1px solid black;
    border-right: 1px solid black;
}
.imagem2 {
    background-image: url("../assets/a2.jpg");
    margin-top: 50px;
    width: 200px;
    height: 200px;
    background-size: cover;
    border-top: 1px solid black;
    border-bottom: 1px solid black;
    border-right: 1px solid black;
}
.imagem3 {
    background-image: url("../assets/a3.png");
    margin-top: 50px;
    width: 200px;
    height: 200px;
    background-size: cover;
    border-top: 1px solid black;
    border-bottom: 1px solid black;
    border-right: 1px solid black;
}
.imagem4 {
    background-image: url("../assets/a4.png");
    margin-top: 50px;
    width: 200px;
    height: 200px;
    background-size: cover;
    border-top: 1px solid black;
    border-bottom: 1px solid black;
    border-right: 1px solid black;
}
.imagem5 {
    background-image: url("../assets/a5.png");
    margin-top: 50px;
    width: 200px;
    height: 200px;
    background-size: cover;
    border-top: 1px solid black;
    border-bottom: 1px solid black;
    border-right: 1px solid black;
}
.imagem6 {
    background-image: url("../assets/a6.png");
    margin-top: 50px;
    width: 200px;
    height: 200px;
    background-size: cover;
    border-top: 1px solid black;
    border-bottom: 1px solid black;
    border-right: 1px solid black;
}
</style>