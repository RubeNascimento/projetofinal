<template>
<div class="background">
  <video loop muted autoplay class="videobackground">
        <source src="../assets/backgroundvideo.mp4" type="video/mp4">
    </video>
</div>
  
</template>

<style scoped>
.videobackground {
  opacity: 0.85;
  z-index: -1;
  width: 100%;
  height: 100%;
  background-size: cover;
  background-position: center;
  display: flex;
  justify-content: center;
  align-items: center;
  font-family: "Metal Mania";
  z-index: -100;
}
</style>
