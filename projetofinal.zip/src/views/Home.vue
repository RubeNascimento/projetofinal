<template>
  <div class="background">
    <div class="caixatexto">
      <h1 class="titulo">Sobre</h1>
      <p>(Informações da página)</p>
    </div>
  </div>
</template>

<script></script>

<style scoped lang="scss">
.background {
  width: 100%;
  height: 100%;
  background-image: url("../assets/event2.png");
  background-size: cover;
  background-position: center;
  display: flex;
  justify-content: center;
  align-items: center;
  font-family: "Metal Mania";
}
.titulo {
  margin-top: 20px;
  font-size: 52px;
}
.caixatexto {
  font-size: 24px;
  opacity: 1;
  width: 1000px;
  height: 600px;
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: rgba(255, 255, 255, 0.26);
  border: 5px solid rgb(109, 0, 0);
}
</style>
