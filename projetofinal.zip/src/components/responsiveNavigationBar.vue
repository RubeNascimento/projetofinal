<template>
  <div class="navbar">
    <nav :style="{ background: background || '#000' }">
      <ul :style="{ background: background || '#000' }" ref="nav">
        <figure ref="logo">
          <div class="barra"></div>
          <div class="backlogo"></div>
          <img
            class="image-logo"
            @click="toggle_nav"
            :src="imagePath"
            height="64px"
            width="64px"
          />
        </figure>
        <li
          v-for="(link, index) in navLinks"
          :key="index"
          @mouseenter="
            $event.currentTarget.style.background =
              hoverBackground || 'rgb(109, 0, 0)'
          "
          @mouseleave="
            $event.currentTarget.style.background = background || '#333'
          "
        >
          <router-link :to="link.path" :style="{ color: linkColor || '#DDD' }">
            {{ link.text }}
          </router-link>
        </li>
      </ul>
    </nav>
  </div>
</template>

<script>
export default {
  props: [
    "navLinks",
    "background",
    "linkColor",
    "hoverBackground",
    "imagePath",
  ],
  methods: {
    toggle_nav() {
      const nav = this.$refs.nav.classList;
      nav.contains("active") ? nav.remove("active") : nav.add("active");
      const logo = this.$ref.logo.classList;
      logo.contains("active") ? logo.remove("active") : logo.add("active");
    },
    toggle_backlogo() {
      const back_logo = this.$refs.backlogo.classList;
      back_logo.contains("ativo")
        ? back_logo.remove("ativo")
        : back_logo.add("ativo");
    },
  },
};
</script>

//
<style scoped lang="scss">
@import "https://unpkg.com/ionicons@4.2.2/dist/css/ionicons.min.css";
.navbar {
  display: flex;
  justify-content: center;
  align-items: center;
  border-bottom: 5px solid rgb(109, 0, 0);
  position: fixed;
  width: 100%;
}
nav {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 36px;
  width: 100%;
  background-color: transparent;
  ul {
    display: flex;
    width: 260px;
    align-items: center;
    position: absolute;
    flex-direction: column;
    top: -400px;
    transition: 500ms ease all;
    padding-top: 60px;
    position: fixed;
    height: 300px;
    border-bottom: 5px solid black;
    border-right: 5px solid black;
    border-left: 5px solid black;

    &.active {
      top: 30px;
      padding-top: 80px;
      border-bottom: 5px solid rgb(109, 0, 0);
      border-right: 5px solid rgb(109, 0, 0);
      border-left: 5px solid rgb(109, 0, 0);
    }
    figure {
      display: flex;
      justify-content: center;
      align-items: center;
      position: fixed;
      z-index: 1;
      top: 12px;
    }

    a {
      text-decoration: none;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: center;
      height: 50px;
      font-size: 24px;
    }

    i {
      margin-right: 10px;
      font-size: 22px;
    }

    li {
      list-style-type: none;
      padding-right: 0;
      padding-left: 0;
      width: 100%;
    }
  }
}
.image-logo {
  cursor: pointer;
}
.image-logo:hover {
  width: 70px;
  height: 70px;
}

.backlogo {
  top: -14px;
  width: 100px;
  height: 100px;
  background-color: black;
  transform: rotate(45deg);
  position: fixed;
  z-index: -1;
}
.barra {
  top: -20px;
  width: 300px;
  height: 56px;
  background-color: black;
  position: fixed;
  z-index: -1;
}
</style>
