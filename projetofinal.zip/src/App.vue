<template>
  <div id="app">
      <responsiveNavigationBar class="navigation"
      :nav-links="navLinks"
      :image-path="require('./assets/metal-vector-logo.png')"
      background="#000"
    />
    <router-view />
  </div>
</template>

<script>
import responsiveNavigationBar from "@/components/responsiveNavigationBar";
export default {
  components: {
    responsiveNavigationBar,
  },
  data: () => ({
    navLinks: [
      {
        text: "Home",
        path: "/",
      },
      {
        text: "About",
        path: "/About",
      },
      {
        text: "Albuns",
        path: "/Albuns",
      },
      {
        text: "Produtos",
        path: "/Produtos",
      },
      {
        text: "Login",
        path: "/Login",
      },
    ],
  }),
};
</script>
<style>
html {
  font-family: "Metal Mania", cursive;
  height: 100%;
  width: 100%;
}
#app {
  height: 100%;
  width: 100%;
}
body {
  height: 100%;
  width: 100%;
}
.navigation {
  z-index: 100;
}
</style>
